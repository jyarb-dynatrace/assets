# Deploying Dynatrace Operator with Azure DevOps (ADO) Pipelines

## Introduction

A value proposition for the Dynatrace solution is the ease with which our customers
can observe and automatically instrument their infrastructure and applications.

For instrumenting Kubernetes clusters, our OneAgent installation is just two steps:
1. Install the Dynatrace Operator via [Helm](https://helm.sh/)
2. Apply the Kubernetes Manifest file `dynakube.yaml`

This guide is for those Azure customers who cannot or will not execute those steps manually.
Instead, they are looking to deploy the Dynatrace operator via code.  While this guide specifically integrates with Azure DevOps Pipelines, the principles and Helm Charts can be applied to any CI/CD pipeline.

## Quick Overview

> See `azure-pipelines.yml` file for the actual Azure Pipeline with all step details

1. Store Dynatrace API Tokens in a credential vault
2. [HelmInstaller@1](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/helm-installer-v1?view=azure-pipelines) Task: _Adds the Helm binary to the Pipeline Agent VM_
3. [HelmDeploy@0](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/helm-deploy-v0?view=azure-pipelines) Task: _Executes the Helm Upgrade command to install the Dynatrace Operator_
4. Install the `dynakube.yaml` manifest
    * Depending on customer requirements, there are two different mechanisms available for deploying `dynakube.yaml`.

        1. Use a custom built Helm Chart version of `dynakube.yaml` so that the pipeline only needs to use [HelmDeploy@0 tasks](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/helm-deploy-v0?view=azure-pipelines).

        1. Store the `dynakube.yaml` file as is and use the [Kubernetes@1 task](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/kubernetes-v1?view=azure-pipelines) to execute a `kubectl apply` command.
        
            Leveraging `envsubst` can assist if `dynakube.yaml` values need to be parameterized.

As this example was built for my customer, this guide leverages the Helm Chart version of `dynakube.yaml` that I've built purposely for this example.

## Prerequisites

### 1. AKS Cluster
In order to instrument a kubernetes cluster, first you need an AKS cluster.
[I leveraged this guide to generate an ARM template with which I could deploy an AKS cluster](https://learn.microsoft.com/en-us/azure/aks/learn/quick-kubernetes-deploy-rm-template?tabs=azure-cli).

In theory, this template could be integrated with the Pipeline so that the cluster is initialized
& monitored with Dynatrace start to finish.  The Pipeline definition in this repo expects the cluster
to be online and a Pipeline Service Connection to already be established.

### 2. Azure DevOps (ADO) Organization

ADO has a concept of "Organizations" that each have their own set of tools bundled together.  Your "pipelines" will live
within an "Organization".

[Please follow the Azure documentation on how to create a new Organization](https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/create-organization?view=azure-devops)

### 3. Kubernetes Service Connection

ADO Pipelines leverages [service connections](https://learn.microsoft.com/en-us/azure/devops/pipelines/library/service-endpoints?view=azure-devops) in order to grant tasks & steps with Azure infrastructure.
Although the Helm and Kubernetes tasks can leverage a `kubeconfig` file, leveraging the service connection turned out to
be much simpler.  This too can be automated with an arm template but otherwise:

1. From within your ADO Organization, click `Project Settings` from the lower left hand corner.
1. Select `Service Connections` from under the `Pipelines` entry.
1. Click on `New service connection` from the top right.
1. Select or search `Kubernetes` and click `Next`.
1. Select `Azure Subscription`, then select your subscription from the `Azure Subscription` dropdown.
1. Next select the appropriate Cluster and give the Service connection an appropriate name.
1. Finalize the connection by clicking on `Save`.

### 4. Store Dynatrace Tokens in a Credential Vault

In order for the Dynatrace OneAgent to communicate to the Dynatrace Cluster, API tokens are provided as part of the onboarding
procedure.  These tokens are traditionally stored as hashed values in the `dynakube.yaml` Manifest file.

In order to avoid committing hard values like the API Tokens to a git repository, we will leverage the variables established by the `values.yaml` file in the `dynakube.yaml` Helm Chart.

We have two options for storing our API Tokens outside of the git repo:

1. [ADO Pipeline Variable Groups](https://learn.microsoft.com/en-us/azure/devops/pipelines/library/variable-groups?view=azure-devops&tabs=yaml)
    - Variable groups are an ADO Pipeline construct which allow you to store pipeline variables in a key, value store.
    - Variables can also be indicated as a secret enabling us to securely store our Dynatrace API Tokens
1. [Azure Key Vault](https://learn.microsoft.com/en-us/azure/key-vault/general/overview)
    - Azure Key Vault is a standalone Azure product which can be used for multiple products.
    - This requires an additional ADO Service Connection which my entitlements did not grant me permission to create.

Given that I could not leverage Azure Key Vault due to my entitlements, this guide will leverage variable groups.
[Please follow this guide on how to create a variable group](https://learn.microsoft.com/en-us/azure/devops/pipelines/library/variable-groups?view=azure-devops&tabs=yaml) with the following keys:

- `dt-api-token`: Maps to Helm Value `api_tokens.operator_token`
- `dt-data-ingest-token`: Maps to Helm Value `api_tokens.data_ingest_token`

There are two additional variables which must be defined for the `dynakube.yaml` Helm chart which could be candidates for storing in a Variable Group.  Those are:
- `dt-api-url`: Maps to Helm Value `api_url`
- `dt-cluster-name`: Maps to Helm Value `cluster_name` 

## Pipeline Steps

### 1. [HelmInstaller@1](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/helm-installer-v1?view=azure-pipelines) Task: _Adds the Helm binary to the Pipeline Agent VM_
ADO Pipelines leverage an "agent" that does the work that the Pipeline Steps require.  Since the Dynatrace Operator is
installed via helm, we need to ensure that the Helm binary is available on that agent before we proceed.

This step simply installs the Helm binary for use in later steps.

### 2. [HelmDeploy@0](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/helm-deploy-v0?view=azure-pipelines) Task: _Executes the Helm Upgrade command to install the Dynatrace Operator_
Now that we have Helm, this step executes a `helm apply` command for the Dynatrace Operator.  We leverage the `helm apply`
command so that whether the operator installation is idempotent.  Aka whether the Operator exists within the cluster or
not, the step will ensure the Operator installation is complete.

Also, to clarify, the operator is pulled and installed from our public repository in this step.

### 3. [HelmDeploy@0](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/helm-deploy-v0?view=azure-pipelines) Task: _Executes a Helm Upgrade command to apply the `dynakube.yaml` manifest file via the custom built Helm Chart_
Now that the Operator has been installed, the final step is to leverage a second Helm Upgrade command to apply our custom `dynakube.yaml` Helm Chart.  Since Helm Charts support out of the box variable substituion, we can directly apply the Pipeline Environment Variables for things like API Tokens to the Helm upgrade command.

In this step we leverage `--set` commands to pass in those environment variables to the Helm Chart.

## Procedure

### Update the Pipeline `azure-pipelines.yml` file

Prior to executing the pipeline, you will need to modify the `azure-pipelines.yml` file to match
your kubernetes service connection.  This is done by referencing the name of the kubernetes service connection.

Please update the `kubernetesServiceConnection` attribute on line 33 and the `kubernetesServiceEndpoint` attribute on
line 44.

### Create the Pipeline
Now that we've established/created all necessary prerequisites, we can now establish the Pipeline.

A pipeline can be created as part of the Azure DevOps Organization that we created earlier.  The new ADO Pipelines
are yaml defined.  This yaml can either be defined via the UI or linked/stored in a Git Repository.  This guide will
leverage a ADO Repo to keep everything integrated under ADO.

#### 1. Create an Azure Repos Git Repository
Before attempting to create an ADO Pipeline, you must first create a repo where you will store the yaml file.

[Please follow this Microsoft Documentation on how to create that ADO Repo](https://learn.microsoft.com/en-us/azure/devops/repos/git/create-new-repo?view=azure-devops)

#### 2. Commit the `azure-pipelines.yml` file & `dynakube` Helm Chart to the new Git Repo
Now that we have a repository which we can point the Pipeline creation process to, we can provision the Pipeline I've
developed as part of this demo.  Please clone and add these files to your repository however you'd like.  For example:

```commandline
git clone git@ssh.dev.azure.com:v3/<USERNAME>/<ORGANIZATION>/<REPO>
git add -A "Initial Commit"
git push
```
#### 3. Create the Pipeline
With our template provisioned, we can simply create a new Pipeline by pointing ADO to the Repo and the
`azure-pipelines.yml` file.

1. From your Organization Click `Pipelines` in the left hand column
1. Click the `New Pipeline` button in the top right corner
1. Select `Azure Repos Git` for "Where is your code?"
1. Select the Repository created in the previous step
1. Select "Existing Azure Pipelines YAML file"
    - If you didn't commit code, you could select starter pipeline and then overwrite the file later
1. In the "Path" dropdown menu, select `azure-pipelines.yml` & then select Continue
1. In the final step you can click on the down arrow next to "Run" and click "Save".

## Images

### Azure Pipeline Executions
![Azure Pipeline Executions](images/azure_pipeline_executions.png)

### Azure Job Details
![Azure Job Details](images/azure_job_details.png)